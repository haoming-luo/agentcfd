# Dependency and license policy

AgentCFD core is Apache-2.0. Mandatory Python dependencies should remain under
permissive licenses whenever practical. Optional engines retain their own
licenses and must be visible in runtime and distribution metadata.

| Component | Role | License posture | Integration rule |
|---|---|---|---|
| NumPy | arrays | BSD | core dependency |
| meshio | mesh interchange | MIT | optional Python dependency |
| Kratos Multiphysics | candidate CFD/CHT engine | BSD-4-Clause | optional provider; application licenses audited individually |
| Cantera | thermochemistry | BSD-3-Clause | optional chemistry provider |
| CoolProp / IF97 | fluid and steam properties | permissive/MIT-style | optional property provider |
| OpenFOAM | industrial finite-volume engine | GPL-3.0 | external executable and case-file boundary |
| SU2 | compressible flow and optimization | LGPL-2.1 | optional external provider |
| preCICE | partitioned coupling | LGPL-3.0 | optional coupling provider |
| Gmsh | meshing | GPL when linked through its API | optional external executable or clearly licensed extra |

AgentCFD will not copy solver code or silently combine incompatible licenses.
Container images, compiled extensions, and commercial distributions receive a
separate dependency and redistribution audit. Calling an external executable
is an architectural boundary, not a substitute for legal review.
