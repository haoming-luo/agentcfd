"""A deliberately external boundary for future OpenFOAM execution."""

from __future__ import annotations

import shutil

from ..errors import UnsupportedCaseError
from .base import ProviderDescriptor


class OpenFOAMProvider:
    """Discover an external OpenFOAM installation without importing GPL code."""

    def descriptor(self) -> ProviderDescriptor:
        commands = ("foamRun", "simpleFoam", "pimpleFoam")
        available = any(shutil.which(command) for command in commands)
        return ProviderDescriptor(
            name="openfoam",
            version="externally-managed",
            license="GPL-3.0-or-later (external program)",
            available=available,
            execution_boundary="filesystem-and-subprocess",
            capabilities=(),
        )

    def run(self, step):
        raise UnsupportedCaseError(
            "OpenFOAM lowering is intentionally not advertised in 0.1.0a1; "
            "the provider boundary exists so it can be added with golden cases and runtime evidence."
        )
